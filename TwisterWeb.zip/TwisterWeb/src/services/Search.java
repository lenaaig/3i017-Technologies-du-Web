package services;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.json.JSONException;
import org.json.JSONObject;

import services.tools.ErrorJSON;
import services.tools.FriendsTools;
import services.tools.SearchTools;
import services.tools.UserTools;

public class Search {

	/**
	 * Liste tous les messages sur la page d'accueil par ordre du plus récent
	 * @param key
	 * @param listAmi
	 * @return JSONObject ("message_accueil", List<Integer>)
	 */
	public static JSONObject listMessageAccueil (String key) {
		if ( key.equals("") )
			return ErrorJSON.serviceRefused("listMessageAccueil: Argument null", -1);
		
		if(!services.tools.UserTools.checkKey(key)){
			Authentification.deconnection(key);
			return ErrorJSON.serviceRefused("listMessageAccueil: clé de session plus valide", 1000);	
		}
		
		List<Integer> listAmi = FriendsTools.listFriendMessage(UserTools.getIdSession(key));
		List<Document> listM = SearchTools.listMessageAccueil(listAmi);
		
		JSONObject obj = new JSONObject();
		try {
			obj.put("message_accueil",listAmi);
		} catch (JSONException e) {
			e.printStackTrace();
			return ErrorJSON.serviceRefused("listMessageAccueil: Error", 100);
		}
		return obj;
	}
	/**
	 * Liste tous les messages sur le profil de l'utilisateur par ordre du plus récent
	 * @param login
	 * @param key
	 * @return JSONObject("message_profil", List<Document>)
	 */
	public static JSONObject listMessageUser (String login, String key) {
		if (login.equals("") || key.equals("") )
			return ErrorJSON.serviceRefused("ListMessageUser: Argument null", -1);
		//Verifie l'existance de la personne :
		if(!services.tools.UserTools.userExist(login))
			return ErrorJSON.serviceRefused("listMessageUser: Ce login n'existe pas", 1000);
		if(!login.equals(services.tools.UserTools.getLogin(key)))
			return ErrorJSON.serviceRefused("listMessageUser: Ce login n'existe pas assicié a la bonne clé", 1000);
		
		if(!services.tools.UserTools.checkKey(key)) {
			Authentification.deconnection(key);
			return ErrorJSON.serviceRefused("listMessageUser: clé de session plus valide", 1000);
		}
				
		ArrayList<Document> list = SearchTools.listMessageUser(login);
		
		JSONObject obj = new JSONObject();
		try {
			obj.put("message_profil",list);
		} catch (JSONException e) {
			e.printStackTrace();
			return ErrorJSON.serviceRefused("listMessageUser: Error", 100);
		}
		return obj;
	}
	/**
	 * Appel des méthodes listMessageAccueil et listMessageUser
	 * @param key
	 * @param login
	 * @param listAmi
	 * @return JSONObject ("message_accueil", List<Integer>) || JSONObject("message_profil", List<Document>)
	 */
	public static JSONObject search(String key, String login, String listAmi) {
		if (listAmi.equals("true"))
			return listMessageAccueil(key);
		//if (query != null) return listMessageQuery();
		return listMessageUser(login, key);
	}
	
}
