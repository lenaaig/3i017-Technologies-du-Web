package services;

import org.json.JSONObject;

import services.tools.ErrorJSON;
import services.tools.MessageTools;
import services.tools.UserTools;

public class Message {

	/**
	 * Ajoute un message (Mongo)
	 * @param key: String
	 * @param text: String
	 * @return JSONObject (refused or accepted)
	 */
	public static JSONObject addMessage (String key, String text) {
		if (key.equals("") || text.equals(""))
			return ErrorJSON.serviceRefused("Argument null", -1);
		//Verifie l'existance de la personne :
		if(!services.tools.UserTools.checkKey(key)){
			Authentification.deconnection(key);
			return ErrorJSON.serviceRefused("addMessage: clé de session plus valide", 1000);	
		}
	
		return MessageTools.addMessage(UserTools.getLogin(key), text, UserTools.getIdSession(key));	
		
	}
	
	/**
	 * Supprime un message (Mongo)
	 * @param key: String
	 * @param id_message: String
	 * @return JSONObject (refused or accepted)
	 */
	public static JSONObject deleteMessage (String key, String id_message) {
		if (key.equals("") || id_message.equals(""))
			return ErrorJSON.serviceRefused("Argument null", -1);
		
		if(!services.tools.UserTools.checkKey(key)){
			Authentification.deconnection(key);
			return ErrorJSON.serviceRefused("deleteMessage: clé de session plus valide", 1000);	
		}
		//Verifie l'existence du message à supprimer
		if(!services.tools.MessageTools.messageExist(id_message))
			return ErrorJSON.serviceRefused("deleteMessage: Ce message n'existe pas", 2000);
	
		return MessageTools.deleteMessage(id_message);	
	}
	
	
}
