package services;

import org.json.JSONObject;

import services.tools.ErrorJSON;
import services.tools.FriendsTools;
import services.tools.UserTools;

public class Amis {

	/**
	 * Ajoute un ami (SQL)
	 * @param key: String
	 * @param id_ami: int
	 * @return JSONObject (refused or accepted)
	 */
	public static JSONObject addFriend(String key, int id_ami) {
		if (key.equals("") || id_ami<0)
			return ErrorJSON.serviceRefused("AddFriend: Argument null", -1);

		//Verifie l'existance de l'ami et si l'user est connecte:
		if(!services.tools.UserTools.checkKey(key)) {
			Authentification.deconnection(key);
			return ErrorJSON.serviceRefused("AddFriend: clé de session plus valide", 1000);	
		}
		if(!services.tools.UserTools.checkID(id_ami))
			return ErrorJSON.serviceRefused("AddFriend: Votre ami n'existe pas", 1000);
		
		//Verifie si id_ami est deja ami avec l'utilisateur
		int id= UserTools.getIdSession(key);
		if(id == id_ami) 
			return ErrorJSON.serviceRefused("AddFriend: Vous ne pouvez pas etre ami avec vous meme..", 1);
		
		if(services.tools.FriendsTools.isFriend(id,id_ami)) 
			return ErrorJSON.serviceRefused("AddFriend: Vous etes deja ami", 1000); // rajouter "ami depuis...."

		return FriendsTools.addFriend(id, id_ami);

	}

	/**
	 * Supprime un ami (SQL)
	 * @param key: String
	 * @param id_ami: int
	 * @return JSONObject (refused or accepted)
	 */
	public static JSONObject deleteFriend(String key, int id_ami) {
		if (key.equals("") || id_ami<0)
			return ErrorJSON.serviceRefused("Friendship: Argument null", -1);

		//Verifie l'existance de l'ami et si l'user est connecte:
		if(!services.tools.UserTools.checkKey(key)) {
			Authentification.deconnection(key);
			return ErrorJSON.serviceRefused("AddFriend: clé de session plus valide", 1000);	
		}
		if(!services.tools.UserTools.checkID(id_ami))
			return ErrorJSON.serviceRefused("AddFriend: Votre ami n'existe pas", 1000);
		
		//Verifie si id_ami n'est pas ami avec l'utilisateur
		int id= UserTools.getIdSession(key);
		if(!services.tools.FriendsTools.isFriend(id,id_ami)) 
			return ErrorJSON.serviceRefused("deleteFriend: Vous n'etes pas ami", 1000); 
		
		return FriendsTools.deleteFriend(id, id_ami);

	}

	/**
	 * Retourne la liste d'amis de l'user
	 * @param user: String
	 * @return JSONObject ("amis", arraylist<Integer>)
	 */
	public static JSONObject listFriend(String user) {
		if (user.equals(""))
			return ErrorJSON.serviceRefused("Friendship: Argument null", -1);
		if(!services.tools.UserTools.userExist(user))
			return ErrorJSON.serviceRefused("listFriend: Ce login n'existe pas", 1000);	
		
		return FriendsTools.listFriend(user);
		
	}
}
