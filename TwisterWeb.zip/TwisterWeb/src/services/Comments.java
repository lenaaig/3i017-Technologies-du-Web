package services;

import org.json.JSONObject;

import services.tools.CommentsTools;
import services.tools.ErrorJSON;
import services.tools.MessageTools;
import services.tools.UserTools;

public class Comments {

	/**
	 * Ajoute un commentaire (Mongo)
	 * @param key: String
	 * @param text: String
	 * @return JSONObject (refused or accepted)
	 */
	public static JSONObject addComments (String key, String text, String id_message) {
		if (key.equals("") || text.equals(""))
			return ErrorJSON.serviceRefused("Argument null", -1);
		//Verifie l'existance de la personne :
		if(!services.tools.UserTools.checkKey(key)){
			Authentification.deconnection(key);
			return ErrorJSON.serviceRefused("addComments: clé de session plus valide", 1000);	
		}
		//Verifie si il existe un message à commenter
		if(!services.tools.MessageTools.messageExist(id_message))
			return ErrorJSON.serviceRefused("addComments: Ce message n'existe pas", 2000);
	
				
		return CommentsTools.addComment(UserTools.getLogin(key), UserTools.getIdSession(key), id_message, text );	

	}
	
	/**
	 * Supprime un commentaire (Mongo)
	 * @param key: String
	 * @param id_message: String
	 * @return JSONObject (refused or accepted)
	 */
	public static JSONObject deleteComments (String key, String id_commentaire, String id_message) {
		if (key.equals("") || id_commentaire.equals(""))
			return ErrorJSON.serviceRefused("Argument null", -1);
		
		if(!services.tools.UserTools.checkKey(key)){
			Authentification.deconnection(key);
			return ErrorJSON.serviceRefused("deleteComments: clé de session plus valide", 1000);	
		}
		
		if(!services.tools.MessageTools.messageExist(id_message))
			return ErrorJSON.serviceRefused("deleteComments: Ce message n'existe pas", 2000);
		//Verifie l'existence du comment à supprimer
		if(!services.tools.MessageTools.messageExist(id_commentaire))
			return ErrorJSON.serviceRefused("deleteComments: Ce message n'existe pas", 2000);
	
		return CommentsTools.deleteComment(UserTools.getLogin(key), UserTools.getIdSession(key), id_message, id_commentaire);
	}
	
	
}
