package services;

import java.sql.Connection;
import java.sql.SQLException;

import org.json.JSONException;
import org.json.JSONObject;

import services.tools.Database;
import services.tools.ErrorJSON;
import services.tools.UserTools;

public class User {
	/**
	 * Création d'un compte utilisateur
	 * @param nom
	 * @param prenom
	 * @param login
	 * @param mdp
	 * @param mail
	 * @return JSONObject (refused or accepted)
	 */
	public static JSONObject createUser(String nom, String prenom, String login, String mdp, String mail) {
		if (nom.equals("") || prenom.equals("") || login.equals("") || mdp.equals("") || mail.equals(""))
			return ErrorJSON.serviceRefused("Argument null", -1);
		if (UserTools.userExist(login)) 
			return ErrorJSON.serviceRefused("Pseudo "+login+" deja existant", 1000);

		return UserTools.insertUser(login, mdp, prenom, nom, mail);
	}
}
