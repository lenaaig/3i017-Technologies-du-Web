package services;

import org.json.JSONException;
import org.json.JSONObject;

import services.tools.ErrorJSON;
import services.tools.UserTools;

public class Authentification {
	
	/**
	 * Permet de se "connecter" (insertion base de donnee session)
	 * @param log (String), mdp (String)
	 * @return JSONObject ("cle", session_key)
	 */
	public static JSONObject login(String log, String mdp) {
		if (log.equals("") || mdp.equals(""))
			return ErrorJSON.serviceRefused("Login: Argument null", -1);
		//Verification du login dans la base de donnee
		if(!services.tools.UserTools.userExist(log))
			return ErrorJSON.serviceRefused("Login: Mauvais Login", 1000);
		//Verification du  mdp
		if(!services.tools.UserTools.checkPassWd(log, mdp))
			return ErrorJSON.serviceRefused("Login: Mauvais Mot de Passe", 100);
		
		return services.tools.UserTools.insertSession(log, false);
	}
	
	/**
	 * Permet de se "deconnecter" (suppression de la base de donnée session)
	 * @param key String
	 * @return JSONObject (accepted or refused)
	 */
	public static JSONObject deconnection(String key) {
		if (key.equals("")) 
			return ErrorJSON.serviceRefused("deconnection: Argument null", -1);
		
		//Verification de la bonne clé de connexion pour deconnecter
		if (!UserTools.checkKey(key))
			return ErrorJSON.serviceRefused("deconnection: Mauvaise clé ", 1000);
		
		return services.tools.UserTools.deconnection(key);
		
	}
}
