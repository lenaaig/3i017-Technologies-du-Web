package services.tools;

import org.bson.Document;
import org.json.JSONObject;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class LikeTools {
	public static JSONObject addLike(String login, int id_message) {
		MongoDatabase c = Connections.getMongoConnection();
		MongoCollection <Document> coll = c.getCollection("message");
		
		Document filter = new Document("id_message", id_message);
		
		Document q = new Document();
		q.append("likes", login );
		Document update =new Document("$inc", q);
		
		coll.updateOne(filter, update);        //db.collection.updateOne(<filter>, <update>, <options>)
		 
		return ErrorJSON.serviceAccepted();
	}	
	
	public static JSONObject deleteLike(String login, int id_message) {
		
		MongoDatabase c = Connections.getMongoConnection();
		MongoCollection <Document> coll = c.getCollection("message");
		
		Document filter = new Document("id_message", id_message);
		
		Document q = new Document();
		q.append("likes", login );
		
		Document likes = new Document();
		likes.append("$inc", -1);
		
		Document update =new Document();
		update.append("likes", likes);
		
		coll.updateOne(filter, update);        //db.collection.updateOne(<filter>, <update>, <options>)
		 
		return ErrorJSON.serviceAccepted();
	}


}
