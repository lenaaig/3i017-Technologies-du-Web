package services.tools;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.json.JSONException;
import org.json.JSONObject;

public class UserTools {
	
	/**
	 * Insertion d'un nouveau User dans la base de donnée
	 * @param login, mdp, prenom, nom, email: String
	 * @return JSONObject (refused or accepted)
	 */
	public static JSONObject insertUser (String login, String mdp, String prenom, String nom, String email){
		try {
			Connection c = Connections.getMySQLConnection();
			String query="insert into user values(DEFAULT, '"+login+"','"+prenom+"','"+nom+"','"+mdp+"','"+email+"')";
			Statement st = c.createStatement();
			int rs= st.executeUpdate(query);

			st.close();
			c.close();
			
			if(rs==0)
				return ErrorJSON.serviceRefused("Failed insertUser", 1000);
			return ErrorJSON.serviceAccepted();
			
		} catch ( SQLException e) {
			e.printStackTrace();
			return ErrorJSON.serviceRefused("Failed insertUser", 1000);
		}
	}
	
	/**
	 * Verifie s'il existe deja un User avec ce login
	 * @param login: String
	 * @return true or false
	 */
	public static boolean userExist (String login) {
		boolean res;
		try {		
			Connection c = Connections.getMySQLConnection();
			String query="select * from user where login_user='"+login+"'";
			Statement st = c.createStatement();
			ResultSet rs= st.executeQuery(query);
			if(rs.next())
				res=true;
			else
				res=false;
			
			st.close();
			c.close();
			
			return res;
		} catch ( SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	
	
	//-----------------PASSWORD-------------------------
	
	/**
	 * Verifie si le mdp et login sont dans la table a la meme colonne
	 * @param login, mdp: String
	 * @return true or false
	 */
	public static boolean checkPassWd(String login, String mdp) {
		boolean res=false;
		try {
			Connection c = Connections.getMySQLConnection();

			String query="select * from user where login_user='"+login+"' and password_user='"+mdp+"'";
			Statement st = c.createStatement();
			ResultSet rs= st.executeQuery(query);
			
			if (rs.next())
				res = true;
			else
				res = false;
			
			st.close();
			c.close();
		} catch ( SQLException e) {
			e.printStackTrace();
		}
		return res;
	}
	
	//-----------------ID-------------------------
	
	/**
	 * Verifie si l'id existe dans la base de donnee "user"
	 * @param id: int
	 * @return true or false
	 */
	public static boolean checkID(int id) {
		boolean res=false;
		try {
			Connection c = Connections.getMySQLConnection();

			String query="select * from user where id_user="+id+"";
			Statement st = c.createStatement();
			ResultSet rs= st.executeQuery(query);
			
			if (rs.next())
				res = true;
			else
				res = false;
			
			st.close();
			c.close();
		} catch ( SQLException e) {
			e.printStackTrace();
		}
		return res;
	}
		
	
	/**
	 * Recupere l'id grace au login dans la table "user"
	 * @param login: String
	 * @return Integer 
	 */
	public static Integer getIdUser(String login) {
		int id=0;
		try {
			Connection c = Connections.getMySQLConnection();

			String query="select id_user from user where login_user='"+login+"'";
			Statement st = c.createStatement();
			ResultSet rs= st.executeQuery(query);
			
			while(rs.next())
				id = rs.getInt("id_user");
			
			st.close();
			c.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return id;
	}
	
	/**
	 * Retourne l'id grace à la cle de session
	 * @param key: String
	 * @return int
	 */
	public static int getIdSession(String key) {
		int id=0;
		try {
			Connection c = Connections.getMySQLConnection();

			String query="select user_id from session where session_key='"+key+"'";
			Statement st = c.createStatement();
			ResultSet rs= st.executeQuery(query);
			
			while(rs.next())
				id = rs.getInt("user_id");
			
			st.close();
			c.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return id;
	}
	
	/**
	 * Recupere le login a partir de la cle de session
	 * @param key: String
	 * @return String
	 */
	public static String getLogin(String key) {
		String login="";
		try {
			Connection c = Connections.getMySQLConnection();
			String query="select login_user from session where session_key='"+key+"'";
			Statement st = c.createStatement();
			ResultSet rs= st.executeQuery(query);
			
			while(rs.next())
				login = rs.getString("login_user");

			st.close();
			c.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return login;
	}
	
	//-----------------KEY-------------------------
	/**
	 * Genere une cle aleatoire de longeur 7
	 * @return String
	 */
	public static String generateKey() {		
		String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	    StringBuilder generatedString = new StringBuilder();
	    for(int i=0; i<7; i++){
	       int index = (int)Math.floor(Math.random() * 62); 
	       generatedString.append(chars.charAt(index));
	    }
		return generatedString.toString();
	}
	
	/**
	 * Verifie s'il n'existe pas une cle similaire dans la table "session"
	 * @param key: String
	 * @return true or false
	 * @throws SQLException 
	 */
	public static boolean checkKey(String key)  {
		try {
			Connection c = Connections.getMySQLConnection();
			Statement st = c.createStatement();
			String query="select session_start, session_root from session where session_key='"+key+"'";
			ResultSet rs= st.executeQuery(query);
		
			if (rs.next()) {
				String date = rs.getString("session_start");
				boolean root = rs.getBoolean("session_root");
				boolean keyValide = keyIsValid(date, root);
				if(!keyValide)
					return false;
				
				//Update date:
				String query2="update session SET session_start='"+FriendsTools.getCurrentDate()+"'  where session_key='"+key+"' ";
				int rs2= st.executeUpdate(query2);
			}
			st.close();
			c.close();
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}
	
	/**
	 * Verifie la date de la cle
	 * @param date: Date
	 * @param root: boolean
	 * @return true or false
	 */
	public static boolean keyIsValid(String date, boolean root) {
		if(root)
			return true;
		GregorianCalendar calendar = new GregorianCalendar();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		try {
			Date d = sdf.parse("2019/02/26 11:08:43");
			//Rajout à la date de session 1heures
			calendar.setTime(d);
			calendar.add(Calendar.HOUR, +1);
			Date session1h = calendar.getTime();
			
			if(FriendsTools.getDate().compareTo(session1h)>0)//Session perimee
				return false;

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return true;
	}
	
	/**
	 * Realise une insertion dans la base de donnée "session"
	 * @param login: String)
	 * @param root: boolean
	 * @return JSONObject({id:.},{login:.},{key:.})
	 */
	public static JSONObject insertSession(String login, boolean root) {
		String date = FriendsTools.getCurrentDate();
		String generatedString;		
		int id=getIdUser(login);
		try {
				Connection c = Connections.getMySQLConnection();
				Statement st = c.createStatement();
				ResultSet rs;
				//Verifie s'il n'y a pas deja une clé similaire dans la base
				do {
					generatedString = generateKey();
					String query="select * from session where session_key='"+generatedString+"'";
					rs= st.executeQuery(query);
				}while(rs.next()); //S'il existe un clé (donc true) on refait le traitement
				
				String query2="insert into session values('"+generatedString+"',"+id+","+root+",'"+date+"','"+login+"')";
				int rs2= st.executeUpdate(query2);
				st.close();
				c.close();
				
				if(rs2==0) //En cas d'erreur de l'insertion
					return ErrorJSON.serviceRefused("Failed Connection Session", 1000);
		} catch ( SQLException e) {
				e.printStackTrace();
				return ErrorJSON.serviceRefused("Failed Connection Session", 1000);
		}
		JSONObject o = new JSONObject();
		try {
				o.put("id", id);
				o.put("login", login);
				o.put("cle",generatedString);
		}catch( JSONException e) {
				System.out.println("Erreur Auth");
				return ErrorJSON.serviceRefused("Failed Connection JSON", 100);
		}
		 return o;
	}
	
	/**
	 * Supprime dans la base de donnee "session" l'utilisateur grace a la cle 
	 * @param key: String
	 */
	public static JSONObject deconnection(String key){
		try {
			Connection c = Connections.getMySQLConnection();
			String query="delete from session where session_key='"+key+"'";
			Statement st = c.createStatement();
			int rs= st.executeUpdate(query);

			st.close();
			c.close();
			
			if(rs==0)
				return ErrorJSON.serviceRefused("Deconnection Error", 1000);
			return ErrorJSON.serviceAccepted();
			
		} catch ( SQLException e) {
			e.printStackTrace();
			return ErrorJSON.serviceRefused("Deconnection Error", 1000);
		}
	}

}
