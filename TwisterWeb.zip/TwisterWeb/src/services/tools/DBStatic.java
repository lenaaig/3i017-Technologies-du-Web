package services.tools;

public class DBStatic {
	public static String mysql_host= "localhost";
	public static String mysql_db= "tasso_pham";
	public static String mysql_username= "root";
	public static String mysql_password= "root";
	public static boolean mysql_pooling = true;
}
