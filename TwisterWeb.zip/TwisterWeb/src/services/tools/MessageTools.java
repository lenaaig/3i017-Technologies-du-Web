package services.tools;

import java.util.ArrayList;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.json.JSONObject;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

public class MessageTools {

	/**
	 * Ajoute un document "message" dans mongobase (login,text,date)
	 * @param login, text: String
	 * @param id: int
	 * @return JSONObject accepted
	 */
	public static JSONObject addMessage(String login, String text, int id) {
		String d = FriendsTools.getCurrentDate();
		MongoDatabase c = Connections.getMongoConnection();
		MongoCollection <Document> coll = c.getCollection("message");
		Document q = new Document();
		q.append("id_user", id);
		q.append("login", login);
		q.append("text", text);
		q.append("date", d);
		q.append("likes", 0);
		q.append("commentaire",new ArrayList<Document>());
		coll.insertOne(q);
		
		return ErrorJSON.serviceAccepted();
	}

	/**
	 * Verifie si le message existe
	 * @param id_message: String (transform into ObjectId)
	 * @return true or false
	 */
	public static boolean messageExist(String id_message) {
		if (id_message.length()!=24)
			return false;
		MongoDatabase c = Connections.getMongoConnection();
		MongoCollection <Document> coll = c.getCollection("message");
		Document q = new Document();
		q.append("_id", new ObjectId(id_message)); 
		MongoCursor<Document> cursor = coll.find(q).iterator();
		if(cursor.hasNext()) {
			System.out.println(cursor.next());
			return true;
		}
		return false;
	}

	/**
	 * Permet de supprimer un message
	 * @param id_message: String
	 * @return JSONObject accepted
	 */
	public static JSONObject deleteMessage(String id_message) {
		MongoDatabase c = Connections.getMongoConnection();
		MongoCollection <Document> coll = c.getCollection("message");
		Document d = new Document();
		d.append("_id", new ObjectId(id_message));
		coll.deleteOne(d);
		return ErrorJSON.serviceAccepted();
	}

	
	
	
}
