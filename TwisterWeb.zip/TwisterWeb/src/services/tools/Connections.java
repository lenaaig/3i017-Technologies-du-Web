package services.tools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class Connections {
	private static Database database = null;
	
	/**
	 * Se connecte selon le pooling
	 * @return Connection
	 * @throws SQLException
	 */
	public static Connection getMySQLConnection() throws SQLException {
		if	(DBStatic.mysql_pooling == false	) {
			String url = "jdbc:mysql://"+ DBStatic.mysql_host +	"/"	+DBStatic.mysql_db;
			return	(DriverManager.getConnection(url, DBStatic.mysql_username, DBStatic.mysql_password));
		}else{
			if (database==null) {	
				database=new Database("jdbc/db");	
			}
			return	database.getConnection();
		}

	}
	
	/**
	 * Connection a SQL (pooling == false)
	 * @return Connection
	 */
	public static Connection getSQLConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		    String url = "jdbc:mysql://localhost/tasso_pham";
			return DriverManager.getConnection(url, "root","root");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * Connection à Mongo
	 * @return MongoDatabase
	 */
	public static MongoDatabase getMongoConnection() {
		MongoClient mongo = MongoClients.create("mongodb://localhost:27017");
		MongoDatabase db = mongo.getDatabase(DBStatic.mysql_db);
		return db;
	}
}
