package services.tools;

import org.bson.Document;
import org.json.JSONObject;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class CommentsTools {
	/**
	 * Ajouter un commentaire à un message
	 * @param login
	 * @param id_user
	 * @param id_message
	 * @param text
	 * @return
	 */
	public static JSONObject addComment(String login, int id_user, String id_message, String text) {
		
		String d = FriendsTools.getCurrentDate();
		MongoDatabase c = Connections.getMongoConnection();
		MongoCollection <Document> coll = c.getCollection("message");
		
		Document filter = new Document("id_message", id_message);

		Document com = new Document();
		com.append("id_user", id_user);
		com.append("login", login);
		com.append("text", text);
		com.append("date", d);
		com.append("likes", 0);

		Document k = new Document();
		k.append("commentaire", com);
		
		Document update = new Document();
		update.append("$push", k);

		coll.updateOne(filter, update);        //db.collection.updateOne(<filter>, <update>, <options>)
		
		return ErrorJSON.serviceAccepted();
	}
	
	
	/**
	 * Supprimer un commentaire
	 * @param login
	 * @param id_user
	 * @param id_message
	 * @param id_commentaire
	 * @return
	 */
	public static JSONObject deleteComment(String login, int id_user, String id_message, String id_commentaire) {
		
		MongoDatabase c = Connections.getMongoConnection();
		MongoCollection <Document> coll = c.getCollection("message");
		
		Document filter = new Document("id_message", id_message);
		Document update = new Document();
		
		Document co = new Document();
		co.append("id_commentaire", id_commentaire);
		
		Document k = new Document();
		k.append("commentaire", co);
		
		update.append("$pull", k);
		
		coll.updateOne(filter, update);

		return ErrorJSON.serviceAccepted();
	}
}
