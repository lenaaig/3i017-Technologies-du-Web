package services.tools;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.json.JSONObject;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

public class SearchTools {
	//chercher sur la barre de recherche: chaine 
	


	/**
	 * Recupere tout les derniers messages du l'user
	 * @param login: String
	 * @return ArrayList<Document>
	 */
	public static ArrayList listMessageUser(String login) {
		ArrayList<Document> msg= new ArrayList();
		MongoDatabase c = Connections.getMongoConnection();
		MongoCollection <Document> coll = c.getCollection("message");
		Document q = new Document();
		q.append("login", login);
		Document d = new Document();
		d.append("date", -1);
		MongoCursor<Document> cursor = coll.find(q).sort(d).iterator();
		while(cursor.hasNext()) {
			msg.add(cursor.next());
		}
		return msg;
	}

	/**
	 * Recupere les derniers messages des amis pour la pas d'accueil 
	 * @param list: List<Integer>
	 * @return ArrayList<Document>
	 */
	public static ArrayList listMessageAccueil(List<Integer> list) { 
		ArrayList<Document> msg= new ArrayList();
		MongoDatabase c = Connections.getMongoConnection();
		MongoCollection <Document> coll = c.getCollection("message");
		
		//Condition:
		Document in = new Document();
		in.append("$in", list);
		
		//Ce qu'on recherche:
		Document q = new Document();
		q.append("id_user", in);
		
		//Trie par date decroissante:
		Document d = new Document();
		d.append("date", -1);
		
		MongoCursor<Document> cursor = coll.find(q).sort(d).iterator();
		while(cursor.hasNext()) {
			msg.add(cursor.next());
		}
		return msg;
	}

}
