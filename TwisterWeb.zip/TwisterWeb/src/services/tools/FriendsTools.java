package services.tools;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

public class FriendsTools {
	
	/**
	 * Retourne la date courante et l'heure
	 * @return "yyyy/MM/dd HH:mm:ss" (String)
	 */
	public static String getCurrentDate() {
		GregorianCalendar calendar = new GregorianCalendar();
		Date d = calendar.getTime();
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String currentTime = sdf.format(d);
		return currentTime;
	}
	
	/**
	 * Recupere la date actuelle
	 * @return Date
	 */
	public static Date getDate() {
		GregorianCalendar calendar = new GregorianCalendar();
		return calendar.getTime();
	}
	

	/**
	 * Ajoute dans la base de donnee friendship (id_1, id_2, date_friendship)
	 * @param login de celui qui ajoute
	 * @param id_ami de celui qui va etre ajouté
	 * @return JSONObject (refused or accepted)
	 */
	public static JSONObject addFriend(int id, int id_ami) {
		String date = getCurrentDate();
		try {
			Connection c = Connections.getMySQLConnection();
			String query="insert into friendship values( "+id+", "+id_ami+", '"+date+"')";
			Statement st = c.createStatement();
			int rs= st.executeUpdate(query);

			st.close();
			c.close();
			
			if(rs==0)
				return ErrorJSON.serviceRefused("AddFriend Error", 1000);
			return ErrorJSON.serviceAccepted();
			
		} catch ( SQLException e) {
			e.printStackTrace();
			return ErrorJSON.serviceRefused("AddFriend Error", 1000);
		}
	}
	
	/**
	 * Verifie si l'id_1 est deja ami avec l'id_2
	 * @param id_1, id_2: int
	 * @return true or false
	 */
	public static boolean isFriend(int id_1, int id_2) {
		boolean res=false;
		try {
			Connection c = Connections.getMySQLConnection();

			String query="select user_id1 from friendship where user_id1="+1+" and user_id2="+3;
			Statement st = c.createStatement();
			ResultSet rs= st.executeQuery(query);
			
			if (rs.next())
				res = true;
			else
				res = false;
			
			st.close();
			c.close();
		} catch ( SQLException e) {
			e.printStackTrace();
		}
		return res;
	}
	
	/**
	 * Supprime l'id_ami de l'user dans la table friendship (methode non reciproque)
	 * @param id: int
	 * @param id_ami: int
	 * @return JSONObject (refused or accepted)
	 */
	public static JSONObject deleteFriend(int id,int id_ami) {
		try {
			Connection c = Connections.getMySQLConnection();
			String query="delete from friendship where user_id1="+id+" and user_id2="+id_ami;
			Statement st = c.createStatement();
			int rs= st.executeUpdate(query);

			st.close();
			c.close();
			
			if(rs==0)
				return ErrorJSON.serviceRefused("deleteFriend Error", 1000);
			return ErrorJSON.serviceAccepted();
			
		} catch ( SQLException e) {
			e.printStackTrace();
			return ErrorJSON.serviceRefused("deleteFriend Error", 1000);
		}
	}
	
	/**
	 * Recupere la liste des amis de l'utilisateur
	 * @param login: String
	 * @return JSONObject ("amis",arraylist <Integer>)
	 */
	public static JSONObject listFriend(String login) {
		List<Integer> amis = new ArrayList<>();
		int id = UserTools.getIdUser(login);
		try {
			Connection c = Connections.getMySQLConnection();
			String query="select user_id2 from friendship where user_id1="+id;
			Statement st = c.createStatement();
			ResultSet rs= st.executeQuery(query);

			while (rs.next()) {
				amis.add(rs.getInt(2));
			}
			
			st.close();
			c.close();
			
			JSONObject o = new JSONObject();
			o.put("amis", amis);
			
			return o;			
		} catch ( SQLException | JSONException e) {
			e.printStackTrace();
			return ErrorJSON.serviceRefused("listFriend Error", 1000);
		}
		
	}
	
	public static List listFriendMessage(int id) {
		List<Integer> amis = new ArrayList<>();
		try {
			Connection c = Connections.getMySQLConnection();
			String query="select user_id2 from friendship where user_id1="+id;
			Statement st = c.createStatement();
			ResultSet rs= st.executeQuery(query);

			while (rs.next()) {
				amis.add(rs.getInt(2));
			}
			
			st.close();
			c.close();
						
		} catch ( SQLException e) {
			e.printStackTrace();
		}
		return amis;
	}


}
