package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

public class CreateCompte extends HttpServlet{
	protected void doGet(HttpServletRequest request, HttpServletResponse reponse) throws IOException, ServletException {
		String nom = request.getParameter("nom");
		String prenom = request.getParameter("prenom");
		String pseudo = request.getParameter("pseudo");
		String mdp = request.getParameter("mdp");
		String mail = request.getParameter("mail");
		
		JSONObject res = services.User.createUser(nom, prenom, pseudo, mdp, mail);
		reponse.setContentType("text/json");
		PrintWriter out = reponse.getWriter();
		out.println(res);
	}

}