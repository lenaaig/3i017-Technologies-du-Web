package test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.GregorianCalendar;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import services.tools.Connections;
import services.tools.ErrorJSON;
import services.tools.UserTools;
import services.tools.FriendsTools;
import services.Amis;


public class TestFriendsTool {

	public static void main(String[] args) {
		/**
		 * Ajouter un ami:OK
		 */ 
		GregorianCalendar calendar = new GregorianCalendar();
		Date d = calendar.getTime();
		System.out.println(calendar.getTime());
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String currentTime = sdf.format(d);
		System.out.println(currentTime);
		
		try {
			Connection c = Connections.getSQLConnection();
			String query="insert into friendship values( 3, 7, '"+currentTime+"')";
			Statement st = c.createStatement();
			int rs= st.executeUpdate(query);

			st.close();
			c.close();
			
			if(rs==0)
				System.out.println("ERREUR");
			System.out.println("OK");
			
		} catch ( SQLException e) {
			e.printStackTrace();
		}
		
		//JSONObject add = FriendsTools.addFriend(3, 6);
		//JSONObject amis = Amis.addFriend(key, id_ami)
		/**
		 * Verifie s'ils sont deja ami:
		 */
		boolean res=false;
		try {
			Connection c = Connections.getSQLConnection();

			String query="select user_id1 from friendship where user_id1="+1+" and user_id2="+3;
			Statement st = c.createStatement();
			ResultSet rs= st.executeQuery(query);
			
			if (rs.next())
				res = true;
			else
				res = false;
			
			st.close();
			c.close();
		} catch ( SQLException e) {
			e.printStackTrace();
		}
		System.out.println("1 et 3 Amis? "+res);
		
		/**
		 * DeleteFriend:OK
		 *//*
		try {
			Connection c = Connections.getSQLConnection();
			String query="delete from friendship where user_id1="+1+" and user_id2="+3;
			Statement st = c.createStatement();
			int rs= st.executeUpdate(query);

			st.close();
			c.close();
			
			if(rs==0)
				System.out.println("ERREUR");
			System.out.println("OK");
			
		} catch ( SQLException e) {
			e.printStackTrace();
		}*/
		//JSONObject d = FriendsTools.deleteFriend(3,6);
		
		/**
		 * ListFriend:OK
		 */
		List<Integer> amis = new ArrayList<>();
		try {
			Connection c = Connections.getSQLConnection();
			String query="select user_id2 from friendship where user_id1="+1;
			Statement st = c.createStatement();
			ResultSet rs= st.executeQuery(query);

			while (rs.next()) {
				amis.add(rs.getInt(1));
			}
			
			st.close();
			c.close();
			
			for(Integer ami: amis) {
				System.out.println(ami);
			}

		} catch ( SQLException e) {
			e.printStackTrace();
		}
	}

	
}
