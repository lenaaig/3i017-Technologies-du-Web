package test;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.json.JSONException;
import org.json.JSONObject;

import services.tools.Connections;
import services.tools.ErrorJSON;
import services.tools.FriendsTools;

import java.sql.Connection;


public class TestCreateUser {

	public static void main(String[] args) {
		//Ca se deploit sur tomcat meme s'il y a une exception
		/*
		try {
			Connection connection = services.tools.Connections.getMySQLConnection();
			String query = "INSERT INTO user VALUES (DEFAULT, 'baby' , 'Nana','lala','m2p','nana@fr')";
			Statement st = connection.createStatement();
			int rs = st.executeUpdate(query);
			st.close();
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}*/
		
		/**
		 * Insertion d'une user: OK
		 *//*
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost/tasso_pham";
			Connection c = DriverManager.getConnection(url, "root","root");
			
			System.out.println("connection reussi??");
			String query = "INSERT INTO user VALUES (DEFAULT, 'rf' , 'lena','test','mdp','crde@xdc')";
			Statement st = c.createStatement();
			int rs = st.executeUpdate(query);
			System.out.println("query???");
			/*while(rs.next()) {
				String prenom = rs.getString("first_name_user");
				System.out.println("prenom : "+prenom);
			}
			st.close();
			c.close();
			if(rs==0)
				System.out.println("ERROR");
			System.out.println(rs);
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} */
		//JSONObject reponse = services.User.createUser("laeti", "a", "a", "ah", "li@");
		
		/**
		 * Verifie le login: OK
		 *//*
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost/tasso_pham";
			Connection c = DriverManager.getConnection(url, "root","root");
			
			System.out.println("connection reussi??");
			String query = "select * from user where login_user='log'";
			Statement st = c.createStatement();
			ResultSet rs = st.executeQuery(query);
			System.out.println("query???");

			
			if(rs.next())
				System.out.println("ok: true");
			else
				System.out.println("erreur");
			st.close();
			c.close();

			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		*/
		//System.out.println("ExistUser? : "+services.tools.UserTools.userExist("log"));
		
		/**
		 * Verifie getId: OK
		 */
		//System.out.println("GetId : "+services.tools.UserTools.getIdUser("toto"));
		
		/**
		 * Verifie mdp: OK
		 */
		//System.out.println("CheckMDP : "+services.tools.UserTools.checkPassWd("toto", "toto"));
		
		/**
		 * Verifie l'Id: OK
		 *//*
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost/tasso_pham";
			Connection c = DriverManager.getConnection(url, "root","root");
			
			System.out.println("connection reussi??");
			String query = "select * from user where id_user=1";
			Statement st = c.createStatement();
			ResultSet rs = st.executeQuery(query);
			System.out.println("query???");

			
			if(rs.next())
				System.out.println("ok");
			else
				System.out.println("erreur");
			st.close();
			c.close();

			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}*/
		//System.out.println("CheckId : "+services.tools.UserTools.checkID(1));
		
		/**
		 * Insert Session:OK
		 */
		String date = FriendsTools.getCurrentDate();
		String generatedString;		 
		/* try {
				Connection c = Connections.getSQLConnection();
				Statement st = c.createStatement();
				ResultSet rs;
				//Verifie s'il n'y a pas deja une cl� similaire dans la base
				do {
					generatedString = services.tools.UserTools.generateKey();
					String query="select * from session where session_key='"+generatedString+"'";
					rs= st.executeQuery(query);
					System.out.println("...");
				}while(rs.next());
				System.out.println("cle fait: "+generatedString + "  date: "+date);
				String query2="insert into session values('"+generatedString+"',1,false,'"+date+"')";
				int rs2= st.executeUpdate(query2);
				st.close();
				c.close();
				System.out.println("close");
				if(rs2==0)
					System.out.println("ERREUR LOGIN");
				
			} catch ( SQLException e) {
				e.printStackTrace();
			}*/
		//JSONObject key = services.tools.UserTools.insertSession("log", false);
		
		/*String date1 = FriendsTools.getCurrentDate();
		String generatedString1;		
		int id=services.tools.UserTools.getIdUser("log");
		try {
				Connection c = Connections.getSQLConnection();
				Statement st = c.createStatement();
				ResultSet rs;
				//Verifie s'il n'y a pas deja une clé similaire dans la base
				do {
					generatedString1 = services.tools.UserTools.generateKey();
					String query="select * from session where session_key='"+generatedString1+"'";
					rs= st.executeQuery(query);
				}while(rs.next()); //S'il existe un clé (donc true) on refait le traitement
				
				String query2="insert into session values('"+generatedString1+"',"+id+",false,'"+date1+"','log')";
				int rs2= st.executeUpdate(query2);
				st.close();
				c.close();
				
				if(rs2==0) //En cas d'erreur de l'insertion
					System.out.println("ERREUR§");
				else 
					System.out.println("ca marche");
		} catch ( SQLException e) {
				e.printStackTrace();
		}*/
		//System.out.println("verification key resultat: "+services.tools.UserTools.checkKey("VQuIzMb"));
		
		/**
		 * Deconnection: OK
		 */
		//services.tools.UserTools.deconnection("VQuIzMb");
		
     
		//String date = rs.getString("session_start");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date d=null;
		try {
			d = sdf.parse("2019/02/26 11:08:43");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(d);
		calendar.add(Calendar.HOUR, +12);
		Date session12 = calendar.getTime();
		System.out.println(session12.toString());
		System.out.println(d.compareTo(FriendsTools.getDate()));
		System.out.println(d.compareTo(d));
		Date dateSessionStart = d ;
		if(FriendsTools.getDate().compareTo(session12)>0)
			System.out.println("datactuelle is after session12"); // clé expiré; à supprimer
	           
	}
}
