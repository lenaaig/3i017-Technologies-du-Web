package test;

import org.json.JSONException;
import org.json.JSONObject;

import services.tools.ErrorJSON;

public class TestServiceTools {

	public static void main(String[] args) {
		//-------------TEST ErrorJSON--------------------//
		JSONObject res = services.tools.ErrorJSON.serviceRefused("ceci est un message", 0);
		if (res == null) {
			System.out.println("pb avec la creation du json");
		}else {
			try {
				System.out.println(res.getString("message") +"  "+ res.getInt("code"));
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		
		//------------------TEST UserTools-------------------//
	}

}
