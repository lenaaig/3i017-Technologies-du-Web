package test;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

import services.tools.Connections;
import services.tools.FriendsTools;
import services.tools.MessageTools;
import services.tools.SearchTools;

public class TestMessageTools {

	public static void main(String[] args) {
		/**
		 * Test addMessage: OK
		 */
		String d = FriendsTools.getCurrentDate();
		MongoDatabase c = Connections.getMongoConnection();
		MongoCollection <Document> coll = c.getCollection("message");
		Document q = new Document();
		q.append("id_user", 1);
		q.append("login", "fe");
		q.append("text", "Message2");
		q.append("date", d);
		q.append("likes", 0);
		q.append("commentaire",new ArrayList<Document>());
		coll.insertOne(q);
		MongoCursor<Document> cursor = coll.find(q).iterator();
		while(cursor.hasNext()) {
			System.out.println(cursor.next());
		}
		//Document{{_id=5c70079f762087747e54704f, login=toto, text=Hello World!, date=2019/02/22 15:30:55}}
		
		/**
		 * Test MessageExist: OK
		 */
		//System.out.println(MessageTools.messageExist("5c7006e7d6530278f60gjyaf3a3"));
		
		/**
		 * Test deleteMsg:OK
		 */
		//MessageTools.deleteMessage("5c750ffa80350e28a4833f01");
		
	}

}
