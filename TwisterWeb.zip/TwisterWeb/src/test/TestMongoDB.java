package test;

import org.bson.Document;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

public class TestMongoDB {
	public static void main(String[] args) {
		MongoClient mongo = MongoClients.create("mongodb://localhost:27017");
		MongoDatabase db = mongo.getDatabase("tasso_pham");
		MongoCollection<Document> coll = db.getCollection("comments");
		Document doc = new Document();
		doc.append("id", 1);
		coll.insertOne(doc);
		
		MongoCursor<Document> cursor = coll.find(doc).iterator();
		while(cursor.hasNext()) {
			System.out.println(cursor.next());
		}
	}
}
