package test;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

import services.tools.Connections;
import services.tools.FriendsTools;

public class TestCommentsTools {

	public static void main(String[] args) {
		/**
		 * Ajout Commentaire:
		 */
		String d = FriendsTools.getCurrentDate();
		MongoDatabase c = Connections.getMongoConnection();
		MongoCollection <Document> coll = c.getCollection("message");
		
		Document filter = new Document("_id", "5c7514d1e5a66072e1a4fae7");

		Document com = new Document();
		com.append("id_user", 5);
		com.append("login", "lili");
		com.append("text", "je reponds a ton message");
		com.append("date", d);
		com.append("likes", 0);

		Document k = new Document();
		k.append("commentaire", com);
		
		Document update = new Document();
		update.append("$push", k);

		coll.updateOne(filter, update);
		//System.out.println("apres update");
		
		MongoCursor<Document> cursor = coll.find(filter).iterator();
		while(cursor.hasNext()) {
			System.out.println(cursor.next());
		}
	}

}
