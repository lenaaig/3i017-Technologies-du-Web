package test;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

import services.tools.Connections;
import services.tools.ErrorJSON;

public class TestLikeTools {

	public static void main(String[] args) {
		/**
		 * Ajout Like
		 */
		MongoDatabase c = Connections.getMongoConnection();
		MongoCollection <Document> coll = c.getCollection("message");
	
		Document filter = new Document("_id", "5c75178bcacd713a487d7607");
		MongoCursor<Document> cursor = coll.find(filter).iterator();
		while(cursor.hasNext()) {
			//int;
		}
		
		Document q = new Document();
		//q.append("likes", );
		Document update =new Document("$inc", q);
		
		coll.updateOne(filter, update);        //db.collection.updateOne(<filter>, <update>, <options>)
		
	}

}
