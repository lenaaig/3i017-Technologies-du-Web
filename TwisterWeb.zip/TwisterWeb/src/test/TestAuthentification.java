package test;

import org.json.JSONException;
import org.json.JSONObject;

import services.tools.ErrorJSON;

public class TestAuthentification {

	public static void main(String[] args) {
		JSONObject res = services.Authentification.login("tot", "mdp");
		System.out.println(res);
		if (res == null)
			System.out.println("pb avec la creation du json");
		
	}
}
