package test;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import services.tools.SearchTools;

public class TestSearchTools {

	public static void main(String[] args) {
		/**
		 * Test listMessageAcccueil: OK
		 */
		
		List <Integer>id= new ArrayList<>();
		id.add(1); 
		id.add(3);
		id.add(6);
		ArrayList<Document> list = SearchTools.listMessageAccueil(id);
		System.out.println("*** Recherche de la liste des users: 1,3 et 6 ***");
		for(Document doc: list) {
			System.out.println(doc);
		}
		
		
		/**
		 * Test listMessageUser: OK
		 */
		ArrayList<Document> list2 = SearchTools.listMessageUser("toto");
		System.out.println("*** Recherche de la liste de l'user :***");
		for(Document doc: list2) {
			System.out.println(doc);
		}
		
	}

}
